Running the Scrapers:
The source codes are present in a folder titled "source code". This folder had the project files kept in different sport domains.

Football Scraper:
The football scraper is in the Folder "football". The project name is footballScraper. 
To run the project you need to install Eclipse. Once installed you need to import the project in the perspective.
Then include the following libraries:
json-simple-1.1.1.jar
jsoup.jar
These jars are present in the project folder. you will need to run the following java files to run the code:

englishFootballScraper.java
spanishLeagueScraper.java

This will generate the necessary JSON files.


